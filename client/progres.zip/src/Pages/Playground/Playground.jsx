import Upload from "../../components/Upload/Upload";
const Playground = () => {
  return (
    <div>
      <Upload />
    </div>
  );
};

export default Playground;
