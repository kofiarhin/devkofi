import Upload from "./components/Upload/Upload";
const App = () => {
  return (
    <div>
      <Upload />
    </div>
  );
};

export default App;
